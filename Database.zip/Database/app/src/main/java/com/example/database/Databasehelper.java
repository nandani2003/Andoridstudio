package com.example.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
    class DatabaseHelper extends SQLiteOpenHelper {
        public static final String Database_name="student.db";
        public static final String Table_name="student_table";
        public static final String Col_1="id";     public static final String Col_2="name";
        public static final String Col_3="surname";     public static final String Col_4="marks";
        public DatabaseHelper(@Nullable context) {
            super(context, Database_name, null, 1);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table "+Table_name+"(id Integer Primary Key,name TEXT, Surname text,Marks Integer)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int             newVersion) {
            db.execSQL("Drop Table IF EXISTS "+Table_name);         onCreate(db);
        }
        public boolean InsertData(int id,String name,String surname,int marks)
        {
            SQLiteDatabase db=this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(Col_1,id);
            contentValues.put(Col_2,name);
            contentValues.put(Col_3,surname);
            contentValues.put(Col_4,marks);
            long result=db.insert(Table_name,null,contentValues);
            if(result==-1)
            {
                return false;
            }         else
            {
                return true;
            }
        }
        public String DisplayData()
        {
            SQLiteDatabase db = this.getReadableDatabase();
            String result = "" ;
            Cursor c=db.rawQuery("SELECT * FROM student_table ",null);         c.moveToFirst();
            while(!c.isAfterLast())
            {
                result = result + c.getString(0)+ " "+c.getString(1)+" "+c.getString(2)+" "+c.getString(3) + "\n";
                c.moveToNext();
            }
            c.close();
            return result;
        }
        public Integer deleteData (String id) {
            SQLiteDatabase db = this.getWritableDatabase();         return db.delete(Table_name, "ID = ?",new String[] {id});
        }
    }




