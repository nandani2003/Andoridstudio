package com.example.database;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button; import android.widget.EditText; import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    DatabaseHelper mydb;
    EditText ed1,ed2,ed3,ed4;
    Button b1,b2;     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydb=new DatabaseHelper(this);
        ed1=(EditText)findViewById(R.id.ed1);
        ed2=(EditText)findViewById(R.id.ed2);
        ed3=(EditText)findViewById(R.id.ed3);
        ed4=(EditText)findViewById(R.id.ed4);
        b1=(Button)findViewById(R.id.b1);
        b2=(Button)findViewById(R.id.b2);
        AddData();
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String DisResult = mydb.DisplayData();


                Toast.makeText(MainActivity.this,DisResult,Toast.LENGTH_LONG).show();
            }
        });
    }
    public void AddData()
    {
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean

                        issaved=mydb.InsertData(Integer.parseInt(ed1.getText().toString()),ed2.getText().toString(),ed3.getText().toString(),Integer.parseInt(ed4.getText().                                 toString()));
                if(issaved==true)
                {
                    Toast.makeText(MainActivity.this,"Data Inserted Successfully",Toast.LENGTH_LONG).show();
                }                 else{
                    Toast.makeText(MainActivity.this,"Data Is not Inserted",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }
};



